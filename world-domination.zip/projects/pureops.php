
                        
                        <!-- Project Overview -->
                        <div style="background: #1a1a1a; border: 1px solid #333; border-radius: 8px; padding: 40px; margin-bottom: 40px;">
                            <h3 style="color: #8B4513; margin-bottom: 20px;">Project Overview</h3>
                            <p style="color: #8B7355; font-size: 18px; line-height: 1.8; margin-bottom: 20px;">
                                PureOps is our advanced DevOps automation platform designed to streamline deployment pipelines, infrastructure management, and continuous integration for scalable software operations. Built from our experience managing Fortune 500 enterprise environments, PureOps brings enterprise-grade automation to teams of all sizes.
                            </p>
                            <p style="color: #8B7355; font-size: 16px; line-height: 1.6;">
                                The platform eliminates the complexity of modern DevOps workflows while maintaining the power and flexibility that enterprise teams require for mission-critical deployments.
                            </p>
                        </div>

                        <!-- Core Features -->
                        <div style="background: #1a1a1a; border: 1px solid #333; border-radius: 8px; padding: 40px; margin-bottom: 40px;">
                            <h3 style="color: #8B4513; margin-bottom: 30px;">Core Capabilities</h3>
                            <div class="row">
                                <div class="col-sm-6">
                                    <ul style="color: #8B7355; line-height: 2;">
                                        <li><strong style="color: #8B4513;">Automated Deployment:</strong> Zero-downtime deployments with rollback capabilities</li>
                                        <li><strong style="color: #8B4513;">Infrastructure as Code:</strong> Terraform and CloudFormation integration</li>
                                        <li><strong style="color: #8B4513;">Pipeline Orchestration:</strong> Visual workflow designer with conditional logic</li>
                                        <li><strong style="color: #8B4513;">Multi-Cloud Support:</strong> AWS, Azure, GCP, and hybrid environments</li>
                                    </ul>
                                </div>
                                <div class="col-sm-6">
                                    <ul style="color: #8B7355; line-height: 2;">
                                        <li><strong style="color: #8B4513;">Monitoring & Alerting:</strong> Real-time performance insights with custom dashboards</li>
                                        <li><strong style="color: #8B4513;">Security Integration:</strong> Automated security scanning and compliance checks</li>
                                        <li><strong style="color: #8B4513;">Container Management:</strong> Docker and Kubernetes native support</li>
                                        <li><strong style="color: #8B4513;">Team Collaboration:</strong> Role-based access with audit trails</li>
                                    </ul>
                                </div>
                            </div>
                        </div>

                        <!-- Technical Architecture -->
                        <div style="background: #1a1a1a; border: 1px solid #333; border-radius: 8px; padding: 40px; margin-bottom: 40px;">
                            <h3 style="color: #8B4513; margin-bottom: 30px;">Technical Architecture</h3>
                            <div class="row">
                                <div class="col-sm-4">
                                    <h4 style="color: #D2B48C; margin-bottom: 15px;">Core Platform</h4>
                                    <p style="color: #8B7355; font-size: 14px;">
                                        Go microservices<br>
                                        gRPC communication<br>
                                        Event-driven architecture<br>
                                        Redis pub/sub<br>
                                        PostgreSQL database
                                    </p>
                                </div>
                                <div class="col-sm-4">
                                    <h4 style="color: #D2B48C; margin-bottom: 15px;">Automation Engine</h4>
                                    <p style="color: #8B7355; font-size: 14px;">
                                        Kubernetes operators<br>
                                        Ansible playbooks<br>
                                        Custom agents<br>
                                        Webhook integrations<br>
                                        API-first design
                                    </p>
                                </div>
                                <div class="col-sm-4">
                                    <h4 style="color: #D2B48C; margin-bottom: 15px;">Frontend</h4>
                                    <p style="color: #8B7355; font-size: 14px;">
                                        React with TypeScript<br>
                                        Real-time WebSocket updates<br>
                                        Responsive design<br>
                                        Dark/light themes<br>
                                        Progressive Web App
                                    </p>
                                </div>
                            </div>
                        </div>

                        <!-- Supported Integrations -->
                        <div style="background: #1a1a1a; border: 1px solid #333; border-radius: 8px; padding: 40px; margin-bottom: 40px;">
                            <h3 style="color: #8B4513; margin-bottom: 30px;">Platform Integrations</h3>
                            <div class="row">
                                <div class="col-sm-3">
                                    <h4 style="color: #D2B48C; margin-bottom: 15px;">Version Control</h4>
                                    <p style="color: #8B7355; font-size: 14px;">
                                        GitHub & GitHub Enterprise<br>
                                        GitLab & GitLab CE<br>
                                        Bitbucket & Bitbucket Server<br>
                                        Azure DevOps Repos<br>
                                        Custom Git servers
                                    </p>
                                </div>
                                <div class="col-sm-3">
                                    <h4 style="color: #D2B48C; margin-bottom: 15px;">Cloud Providers</h4>
                                    <p style="color: #8B7355; font-size: 14px;">
                                        AWS (EC2, ECS, Lambda)<br>
                                        Microsoft Azure<br>
                                        Google Cloud Platform<br>
                                        DigitalOcean<br>
                                        Bare metal servers
                                    </p>
                                </div>
                                <div class="col-sm-3">
                                    <h4 style="color: #D2B48C; margin-bottom: 15px;">Monitoring</h4>
                                    <p style="color: #8B7355; font-size: 14px;">
                                        Prometheus & Grafana<br>
                                        Datadog<br>
                                        New Relic<br>
                                        Splunk<br>
                                        ELK Stack
                                    </p>
                                </div>
                                <div class="col-sm-3">
                                    <h4 style="color: #D2B48C; margin-bottom: 15px;">Communication</h4>
                                    <p style="color: #8B7355; font-size: 14px;">
                                        Slack notifications<br>
                                        Microsoft Teams<br>
                                        Discord webhooks<br>
                                        Email alerts<br>
                                        SMS notifications
                                    </p>
                                </div>
                            </div>
                        </div>

                        <!-- Use Cases -->
                        <div style="background: #1a1a1a; border: 1px solid #333; border-radius: 8px; padding: 40px; margin-bottom: 40px;">
                            <h3 style="color: #8B4513; margin-bottom: 30px;">Perfect For</h3>
                            <div class="row">
                                <div class="col-sm-6">
                                    <div style="padding: 20px; background: rgba(0, 200, 81, 0.05); border: 1px solid rgba(0, 200, 81, 0.2); border-radius: 6px; margin-bottom: 20px;">
                                        <h4 style="color: #8B4513; margin-bottom: 10px;">Startups & Scale-ups</h4>
                                        <p style="color: #8B7355; font-size: 14px;">Establish professional DevOps practices from day one without the enterprise overhead.</p>
                                    </div>
                                </div>
                                <div class="col-sm-6">
                                    <div style="padding: 20px; background: rgba(0, 200, 81, 0.05); border: 1px solid rgba(0, 200, 81, 0.2); border-radius: 6px; margin-bottom: 20px;">
                                        <h4 style="color: #8B4513; margin-bottom: 10px;">Enterprise Teams</h4>
                                        <p style="color: #8B7355; font-size: 14px;">Standardize deployment processes across multiple teams and environments.</p>
                                    </div>
                                </div>
                                <div class="col-sm-6">
                                    <div style="padding: 20px; background: rgba(0, 200, 81, 0.05); border: 1px solid rgba(0, 200, 81, 0.2); border-radius: 6px; margin-bottom: 20px;">
                                        <h4 style="color: #8B4513; margin-bottom: 10px;">Development Agencies</h4>
                                        <p style="color: #8B7355; font-size: 14px;">Streamline client project deployments with consistent, reliable automation.</p>
                                    </div>
                                </div>
                                <div class="col-sm-6">
                                    <div style="padding: 20px; background: rgba(0, 200, 81, 0.05); border: 1px solid rgba(0, 200, 81, 0.2); border-radius: 6px; margin-bottom: 20px;">
                                        <h4 style="color: #8B4513; margin-bottom: 10px;">Game Development</h4>
                                        <p style="color: #8B7355; font-size: 14px;">Automated game server deployments with integrated CDN and update management.</p>
                                    </div>
                                </div>
                            </div>
                        </div>

                        <!-- Development Status -->
                        <div style="background: #1a1a1a; border: 1px solid #333; border-radius: 8px; padding: 40px; margin-bottom: 40px;">
                            <h3 style="color: #8B4513; margin-bottom: 20px;">Development Progress</h3>
                            <div style="margin-bottom: 20px;">
                                <div style="display: flex; justify-content: space-between; align-items: center; margin-bottom: 10px;">
                                    <span style="color: #8B7355; font-weight: bold;">Core Platform & API</span>
                                    <span style="color: #8B4513; font-weight: bold;">90%</span>
                                </div>
                                <div style="background: #333; height: 8px; border-radius: 4px;">
                                    <div style="background: #8B4513; height: 100%; width: 90%; border-radius: 4px;"></div>
                                </div>
                            </div>
                            <div style="margin-bottom: 20px;">
                                <div style="display: flex; justify-content: space-between; align-items: center; margin-bottom: 10px;">
                                    <span style="color: #8B7355; font-weight: bold;">Frontend Dashboard</span>
                                    <span style="color: #8B4513; font-weight: bold;">75%</span>
                                </div>
                                <div style="background: #333; height: 8px; border-radius: 4px;">
                                    <div style="background: #8B4513; height: 100%; width: 75%; border-radius: 4px;"></div>
                                </div>
                            </div>
                            <div style="margin-bottom: 20px;">
                                <div style="display: flex; justify-content: space-between; align-items: center; margin-bottom: 10px;">
                                    <span style="color: #8B7355; font-weight: bold;">Cloud Integrations</span>
                                    <span style="color: #8B4513; font-weight: bold;">65%</span>
                                </div>
                                <div style="background: #333; height: 8px; border-radius: 4px;">
                                    <div style="background: #8B4513; height: 100%; width: 65%; border-radius: 4px;"></div>
                                </div>
                            </div>
                        </div>

                        <!-- Call to Action -->
                        <div style="text-align: center; padding: 40px;">
                            <h3 style="color: #8B4513; margin-bottom: 20px;">Ready to Simplify Your DevOps?</h3>
                            <p style="color: #8B7355; font-size: 16px; margin-bottom: 30px;">
                                Join our beta program to experience enterprise-grade automation without the complexity.
                            </p>
                            <a href="/contact" style="display: inline-block; background: #8B4513; color: #0f1419; padding: 15px 30px; text-decoration: none; border-radius: 8px; font-weight: bold; transition: all 0.3s ease; margin-right: 15px;">
                                Join Beta Program
                            </a>
                            <a href="/contact" style="display: inline-block; background: transparent; color: #8B4513; border: 1px solid #8B4513; padding: 15px 30px; text-decoration: none; border-radius: 8px; font-weight: bold; transition: all 0.3s ease;">
                                Enterprise Demo
                            </a>
                        </div>
